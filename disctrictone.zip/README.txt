vào 1 cái space ở districtone r bấm f12 bật network, search chữ latest tìm cái như trong ảnh đính kèm. lấy thông tin rồi add vào file
wallets.txt định dạng như sau, mỗi acc 1 dòng:

sig|user_id|time_create|wallet_address

sửa space_id trong file config, key captcha dùng của em k cần sửa cũng dc

cài thư viện:
npm install 

chạy bot:
node run