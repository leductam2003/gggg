const fs = require('fs')
    , ethers = require('ethers')
    , axios = require('axios')
    , moment = require('moment-timezone')

const batchWalletsPrivateKeys = (fs.readFileSync('./privateKeys.txt', 'utf-8')).trim().split('\n');
const provider = new ethers.JsonRpcProvider('https://rpc.blast.io	');

function logWithTime(message, type = 'info') {
    const date = new Date();
    const time = date.toLocaleTimeString('vi-VN', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const milliseconds = date.getMilliseconds().toString().padStart(3, '0');
    if (type == 'r') {
        console.error('\x1b[31m%s\x1b[0m', `[ERROR] [${time}.${milliseconds}] ${message}`);
    }
    if (type == 'i') {
        console.log(`[INFO] [${time}.${milliseconds}] ${message}`);
    }
    if (type == 's') {
        console.log('\x1b[32m%s\x1b[0m', `[SUCCESS] [${time}.${milliseconds}] ${message}`);
    }
}

async function execute_task() {
    const tasks = batchWalletsPrivateKeys.map(async (user) => {
        main(user.replace('\r', ''));
    });
    await Promise.all(tasks);
}


async function login(address, signature, time) {
    let data = JSON.stringify({
        "wallet": address,
        "sign": signature,
        "createdAtUtc": time
    });
    let config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: 'https://districtone.io/api/user/login',
        headers: {
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': 'no-cache',
            'content-type': 'application/json',
            'createdatutc': time,
            'origin': 'https://districtone.io',
            'pragma': 'no-cache',
            'referer': 'https://districtone.io/space',
            'sec-ch-ua': '"Google Chrome";v="123", "Not:A-Brand";v="8", "Chromium";v="123"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'sig': signature,
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
            'version': 'v.0.0.0.3'
        },
        data: data
    };
    try {
        const response = await axios.request(config)
        if (response.status === 200) {
            return response.data
        }
    } catch (error) {
        console.error(error)
    }
}



async function main(privateKey) {
    const wallet = new ethers.Wallet(privateKey, provider)
    const time = Date.now()
    const $ = moment(time).utc().format("DD MMM, YYYY HH:mm:ss");
    const message = `Please sign this message to confirm your identity for a safe login DistrictOne, at no cost and without making any transactions.\n\nIt's simply to prove you own your Ethereum wallet.\n\nDate and Time: ${$} UTC`;
    const signature = await wallet.signMessage(message)
    const user = await login(wallet.address, signature, time)
    if (!user){
        throw Error('Login failed!!!')
    }
    logWithTime(`${wallet.address} | Logged in!!!`,'s')
    fs.appendFileSync('users.txt', `${signature}|${user.id}|${time}|${wallet.address}\n`)
}

(async () => {
    await execute_task()
})();