const fs = require('fs')
    , ini = require('ini')
    , axios = require('axios')
    , CapSolver = require('capsolver-npm')
    , WebSocket = require('ws')
    , { CapMonsterCloudClientFactory, ClientOptions, RecaptchaV3ProxylessRequest, RecaptchaV2ProxylessRequest, RecaptchaV2EnterpriseTaskProxyless, RecaptchaV2EnterpriseProxylessRequest } = require('@zennolab_com/capmonstercloud-client');

const config = ini.parse(fs.readFileSync('./config.ini', 'utf-8'));
const batchWalletsPrivateKeys = (fs.readFileSync('./wallets.txt', 'utf-8')).trim().split('\n');

function logWithTime(message, type = 'info') {
    const date = new Date();
    const time = date.toLocaleTimeString('vi-VN', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const milliseconds = date.getMilliseconds().toString().padStart(3, '0');
    if (type == 'r') {
        console.error('\x1b[31m%s\x1b[0m', `[ERROR] [${time}.${milliseconds}] ${message}`);
    }
    if (type == 'i') {
        console.log(`[INFO] [${time}.${milliseconds}] ${message}`);
    }
    if (type == 's') {
        console.log('\x1b[32m%s\x1b[0m', `[SUCCESS] [${time}.${milliseconds}] ${message}`);
    }
}

async function execute_task() {
    const tasks = batchWalletsPrivateKeys.map(async (user) => {
        main(user.replace('\r', '').split('|'));
    });
    await Promise.all(tasks);
}

async function get_rally_info(user) {
    let config_rq = {
        method: 'get',
        maxBodyLength: Infinity,
        url: 'https://districtone.io/api/stage/' + config.settings.space_id,
        headers: {
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': 'no-cache',
            'createdatutc': user[2],
            'pragma': 'no-cache',
            'referer': 'https://districtone.io/space/' + config.settings.space_id,
            'sec-ch-ua': '"Google Chrome";v="123", "Not:A-Brand";v="8", "Chromium";v="123"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'sig': user[0],
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
            'userid': user[1],
            'version': 'v.0.0.0.3'
        }
    };

    try {
        const response = await axios.request(config_rq)
        if (response.status === 200) {
            return response.data.rallyInfo
        }
    } catch (error) {
        console.error(error)
    }
}

async function recaptchaSolverCapmonster(_pageAction) {
    const cmcClient = CapMonsterCloudClientFactory.Create(new ClientOptions({ clientKey: '21dca6f784fd75c952d4e4681fbcb654' }));
    const recaptchaV2ProxylessRequest = new RecaptchaV3ProxylessRequest({
      websiteURL: 'https://districtone.io/space/' + config.settings.space_id,
      websiteKey: "6LedoJEpAAAAAK_x3ZehdvzTUuasTBzUQwFJqTsz",
      minScore: 0.9,
      pageAction: _pageAction
    });
    const response = await cmcClient.Solve(recaptchaV2ProxylessRequest)
    if (!response.error) {
      return response.solution.gRecaptchaResponse
    }
  }
async function recaptchaSolver(_pageAction) {
    const handler = new CapSolver(config.settings.capsolver_key)
    let b = await handler.balance();
    if (b > 0) {
        logWithTime('solving recaptcha v3....', 'i')
        const response = await handler.recaptchav3proxyless(
            'https://districtone.io/space/' + config.settings.space_id, 
            '6LedoJEpAAAAAK_x3ZehdvzTUuasTBzUQwFJqTsz',
             _pageAction, 
             minScore = 0.9)
        return response.solution.gRecaptchaResponse
    }
}
function rally_time() {
    return [
        {
            start: new Date().setUTCHours(0, 0, 0, 0),
            end: new Date().setUTCHours(0, 15, 0, 0),
        },
        {
            start: new Date().setUTCHours(2, 0, 0, 0),
            end: new Date().setUTCHours(2, 15, 0, 0)
        },
        {
            start: new Date().setUTCHours(4, 0, 0, 0),
            end: new Date().setUTCHours(4, 15, 0, 0),
        },
        {
            start: new Date().setUTCHours(6, 0, 0, 0),
            end: new Date().setUTCHours(6, 15, 0, 0),
        },
        {
            start: new Date().setUTCHours(8, 0, 0, 0),
            end: new Date().setUTCHours(8, 15, 0, 0),
        },
        {
            start: new Date().setUTCHours(10, 0, 0, 0),
            end: new Date().setUTCHours(10, 15, 0, 0),
        },
        {
            start: new Date().setUTCHours(12, 0, 0, 0),
            end: new Date().setUTCHours(12, 15, 0, 0),
        },
        {
            start: new Date().setUTCHours(14, 0, 0, 0),
            end: new Date().setUTCHours(14, 15, 0, 0),
        },
        {
            start: new Date().setUTCHours(16, 0, 0, 0),
            end: new Date().setUTCHours(16, 15, 0, 0),
        },
        {
            start: new Date().setUTCHours(18, 0, 0),
            end: new Date().setUTCHours(18, 15, 0),
        },
        {
            start: new Date().setUTCHours(20, 0, 0) ,
            end: new Date().setUTCHours(20, 15, 0),
        },
        {
            start: new Date().setUTCHours(22, 0, 0),
            end: new Date().setUTCHours(22, 15, 0),
        },
        {
            start: new Date().setUTCHours(0, 0, 0) + (24 * 60 * 60 * 1000),
            end: new Date().setUTCHours(0, 15, 0) + (24 * 60 * 60 * 1000),
        },
    ]
}
async function rally(user) {
    const recaptchaToken = await recaptchaSolver('claimAirdrop')
    let data = JSON.stringify({
        "recaptchaToken": recaptchaToken,
        "recaptchaVersion": "V3"
    });
    let config_rq = {
        method: 'post',
        maxBodyLength: Infinity,
        url: `https://districtone.io/api/stage/${config.settings.space_id}/light-up/claim`,
        headers: {
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': 'no-cache',
            'createdatutc': user[2],
            'pragma': 'no-cache',
            'referer': 'https://districtone.io/space/' + config.settings.space_id,
            'sec-ch-ua': '"Google Chrome";v="123", "Not:A-Brand";v="8", "Chromium";v="123"',
            'content-type': 'application/json',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'sig': user[0],
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
            'userid': user[1],
            'version': 'v.0.0.0.3'

        },
        data: data
    };
    let resolved = false
    do {
        try {
            const response = await axios.request(config_rq)
            if (response.status === 200) {
                resolved = true
                logWithTime('Rally done!!!', 's')
                return response.data;
            }
        } catch (error) {
            if (error.response.data.message !== 'Verification failed, please try again later') {
                resolved = true
            }
            logWithTime(`${user[1]} | ${error.response.data.message}`, 'r')
        }
    } while (!resolved);
}
async function claim(user, drop_id) {
    const recaptchaToken = await recaptchaSolver('claimAirdrop')
    let data = JSON.stringify({
        "recaptchaToken": recaptchaToken,
        "recaptchaVersion": "V3"
    });
    let config_rq = {
        method: 'post',
        maxBodyLength: Infinity,
        url: `https://districtone.io/api/stage/${config.settings.space_id}/lucky-drop/${drop_id}/claim`,
        headers: {
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': 'no-cache',
            'createdatutc': user[2],
            'pragma': 'no-cache',
            'referer': 'https://districtone.io/space/' + config.settings.space_id,
            'sec-ch-ua': '"Google Chrome";v="123", "Not:A-Brand";v="8", "Chromium";v="123"',
            'content-type': 'application/json',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'sig': user[0],
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
            'userid': user[1],
            'version': 'v.0.0.0.3'
        },
        data: data
    };
    let resolved = false
    do {
        try {
            const response = await axios.request(config_rq)
            if (response.status === 200) {
                resolved = true
                logWithTime('Claimmed '.concat(response.data.amount), 's')
                return response.data;
            }
        } catch (error) {
            if (error.response.data.message !== 'Verification failed, please try again later') {
                resolved = true
            }
            logWithTime(`${user[1]} | ${error.response.data.message}`, 'r')
        }
    } while (!resolved);
}


async function listening_space(user) {
    const ws = new WebSocket(`wss://districtone.io/socket.io/?sig=${user[0]}&createdAtUtc=${user[2]}&userId=${user[1]}&wallet=${user[3]}&EIO=4&transport=websocket`);
    ws.on('open', function open() {
        setTimeout(() => {
            ws.send(`420["joinStage",{"stageId":589,"sender":"8e4677081387456086799e9f3176a93e","sig":"0x313b6bb72f47fe9d8d3c6de5a68a62974a1a3c398265b08e5300d8021201bdb07021aa1beae8fe968afc1ad43fa5ee656427b5d2d1f089d6ac2aab85fb999cea1c","createdAtUtc":1711524414587}]`)
        }, 500);
        setInterval(() => {
            ws.send('3')
        }, 1000);
    });
    let rallied = false;
    ws.on('message', async function incoming(data) {
        try {
            const bufferString = data.toString('utf8');
            const cleanedJsonString = bufferString.replace(/^\d+/, '');
            const rally_times = rally_time()
            for (const r of rally_times) {
                const current_time = new Date();
                const rally_start_time = new Date(r['start']);
                const rally_end_time = new Date(r['end']);
                if (current_time >= rally_start_time && current_time < rally_end_time) {
                    if (!rallied) {
                        rallied = true;
                        await rally(user)
                    }
                }
            };
            if (cleanedJsonString.includes('newLucky')) {
                const response = JSON.parse(cleanedJsonString);
                const content = JSON.parse(response[1].message.content)
                if (JSON.stringify(content).includes('luckyId')) {
                    rallied = false
                    const lucky_type = content.luckyType;
                    const lucky_id = content.luckyId;
                    const lucky_count = content.count;
                    logWithTime(`LUCKY ID: ${lucky_id} | TYPE: ${lucky_type} | COUNT: ${lucky_count}`, 'i')
                    await claim(user, lucky_id)
                }
            }
        } catch (error) {
            console.error(error)
        }
    });
}

async function main(user) {
    logWithTime(`${user[3]} | Listening to the new lucky drop...`, 'i')
    await listening_space(user);
}


(async () => {
    await execute_task()
})();